package com.dynamicisland.app

import android.graphics.Rect
import android.os.Build
import android.view.WindowInsets

/** Deteksi punch hole / poni (notch) yang menyentuh tepi atas layar. */
object Cutout {
    fun top(ins: WindowInsets?): Rect? {
        if (Build.VERSION.SDK_INT < 28) return null
        val dc = ins?.displayCutout ?: return null
        return dc.boundingRects.filter { it.top <= 1 && it.width() > 0 }.maxByOrNull { it.width() }
    }

    fun label(r: Rect, screenW: Int) = if (r.width() < screenW * 0.12f) "Punch hole" else "Poni (notch)"
}
