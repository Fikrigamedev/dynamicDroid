package com.dynamicisland.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import com.google.android.material.R as M
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {
    private lateinit var p: SharedPreferences
    private val refreshers = mutableListOf<() -> Unit>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun color(attr: Int) = MaterialColors.getColor(this, attr, 0)

    private fun tv(t: String, style: Int, muted: Boolean = false) = TextView(this).apply {
        text = t; setTextAppearance(style)
        if (muted) setTextColor(color(M.attr.colorOnSurfaceVariant))
    }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun card(title: String, vararg v: View): View {
        val inner = col().apply { setPadding(dp(20), dp(16), dp(20), dp(12)) }
        inner.addView(tv(title, M.style.TextAppearance_Material3_LabelLarge).apply { setTextColor(color(M.attr.colorPrimary)) })
        v.forEach { inner.addView(it) }
        return MaterialCardView(this).apply {
            radius = dp(28).toFloat(); cardElevation = 0f; strokeWidth = 0
            setCardBackgroundColor(color(M.attr.colorSurfaceContainer))
            addView(inner)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        }
    }

    private fun info(t: String, d: String) = col().apply {
        addView(tv(t, M.style.TextAppearance_Material3_BodyLarge))
        addView(tv(d, M.style.TextAppearance_Material3_BodyMedium, true))
    }

    private fun switchRow(t: String, d: String, key: String, def: Boolean, extra: ((Boolean) -> Unit)? = null): View =
        LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8))
            addView(info(t, d), LinearLayout.LayoutParams(0, -2, 1f))
            addView(MaterialSwitch(context).apply {
                isChecked = p.getBoolean(key, def)
                setOnCheckedChangeListener { _, c -> p.edit().putBoolean(key, c).apply(); extra?.invoke(c) }
            })
        }

    private fun sliderRow(label: String, key: String, def: Int, min: Int, max: Int, unit: String): View {
        val value = tv("${p.getInt(key, def)} $unit", M.style.TextAppearance_Material3_BodyMedium, true)
        val head = LinearLayout(this).apply {
            addView(tv(label, M.style.TextAppearance_Material3_BodyLarge), LinearLayout.LayoutParams(0, -2, 1f)); addView(value)
        }
        val s = Slider(this).apply {
            valueFrom = min.toFloat(); valueTo = max.toFloat(); stepSize = 1f; this.value = p.getInt(key, def).toFloat()
            addOnChangeListener { _, v, _ -> p.edit().putInt(key, v.toInt()).apply(); value.text = "${v.toInt()} $unit" }
        }
        return col().apply { setPadding(0, dp(8), 0, 0); addView(head); addView(s) }
    }

    private fun permRow(t: String, d: String, ok: () -> Boolean, open: () -> Unit): View {
        val status = tv("", M.style.TextAppearance_Material3_LabelMedium)
        val btn = MaterialButton(this, null, M.attr.materialButtonOutlinedStyle).apply { text = "Atur"; setOnClickListener { open() } }
        refreshers += {
            val g = ok()
            status.text = if (g) "✓ Aktif" else "Belum aktif"
            status.setTextColor(color(if (g) M.attr.colorPrimary else M.attr.colorError))
        }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, dp(8))
            addView(col().apply { addView(info(t, d)); addView(status) }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(btn)
        }
    }

    /** Kartu utama bergaya "main switch" Settings Android modern. */
    private fun hero(): View {
        val onC = color(M.attr.colorOnPrimaryContainer)
        val status = tv("", M.style.TextAppearance_Material3_BodyMedium).apply { setTextColor(onC) }
        fun upd() {
            status.text = when {
                !p.getBoolean("enabled", false) -> "Nonaktif"
                !a11yOn() -> "Perlu izin Aksesibilitas"
                else -> "Aktif"
            }
        }
        refreshers += { upd() }
        val sw = MaterialSwitch(this).apply {
            isChecked = p.getBoolean("enabled", false)
            setOnCheckedChangeListener { _, c ->
                p.edit().putBoolean("enabled", c).apply()
                if (c && !a11yOn()) {
                    Toast.makeText(context, "Aktifkan \"Dynamic Island\" di Aksesibilitas", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                upd()
            }
        }
        val texts = col().apply {
            addView(tv("Dynamic Island", M.style.TextAppearance_Material3_TitleLarge).apply { setTextColor(onC) })
            addView(status)
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(24), dp(22), dp(24), dp(22))
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f)); addView(sw)
        }
        return MaterialCardView(this).apply {
            radius = dp(32).toFloat(); cardElevation = 0f; strokeWidth = 0
            setCardBackgroundColor(color(M.attr.colorPrimaryContainer))
            addView(row)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        }
    }

    private fun preview(): View {
        fun ic(res: Int, s: Int) = ImageView(this).apply { setImageResource(res); layoutParams = LinearLayout.LayoutParams(dp(s), dp(s)) }
        fun t(x: String, sz: Float, a: Int) = TextView(this).apply { text = x; textSize = sz; setTextColor(Color.argb(a, 255, 255, 255)); setSingleLine() }
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(22), 0, dp(14), 0)
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = dp(32).toFloat() }
            addView(ic(R.drawable.ic_music, 20))
            addView(col().apply { addView(t("Now Playing", 13f, 255)); addView(t("Playing · Demo", 11f, 140)) },
                LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(16) })
            addView(ic(R.drawable.ic_pause, 15).apply {
                setPadding(dp(10), dp(10), dp(10), dp(10)); layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1FFFFFFF) }
            })
            layoutParams = LinearLayout.LayoutParams(-1, dp(64)).apply { topMargin = dp(8); bottomMargin = dp(12) }
        }
        val cut = tv("", M.style.TextAppearance_Material3_BodySmall, true)
        refreshers += {
            window.decorView.post {
                val r = Cutout.top(window.decorView.rootWindowInsets); val d = resources.displayMetrics.density
                cut.text = if (r == null) "Layar: tanpa poni / punch hole — pill standar di tengah atas."
                else "Layar: ${Cutout.label(r, resources.displayMetrics.widthPixels)} terdeteksi (${(r.width() / d).toInt()}×${(r.height() / d).toInt()} dp) — pill disejajarkan otomatis."
            }
        }
        return card("Pratinjau", pill, cut)
    }

    private fun a11yOn() = (Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
        .contains("$packageName/")
    private fun notifOn() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
    private fun batteryOk() = (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = getSharedPreferences("island", MODE_PRIVATE)
        val c = col().apply { setPadding(dp(16), dp(24), dp(16), dp(32)) }
        c.addView(hero())
        c.addView(preview())

        c.addView(card("Layar",
            switchRow("Sesuaikan punch hole / poni", "Pill mengikuti posisi & ukuran kamera; konten terbuka di bawah kamera", "cutout", true),
            switchRow("Mode standby", "Pill kecil tetap tampil walau tidak ada fitur aktif", "standby", true)))

        c.addView(card("Izin khusus",
            permRow("Overlay / Aksesibilitas", "Menggambar di atas status bar & menutupi pulau bawaan", ::a11yOn) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            },
            permRow("Akses notifikasi", "Membaca sesi musik (judul, artis, play/pause)", ::notifOn) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            },
            permRow("Abaikan optimasi baterai", "Agar tidak dimatikan sistem saat standby", ::batteryOk) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            },
            tv("Android 13+: bila izin abu-abu, buka Info aplikasi → ⋮ → \"Izinkan setelan terbatas\".", M.style.TextAppearance_Material3_BodySmall, true),
            MaterialButton(this, null, M.attr.borderlessButtonStyle).apply {
                text = "Buka Info aplikasi"
                setOnClickListener { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) }
            }))

        c.addView(card("Fitur live",
            switchRow("Musik", "Judul, artis & kontrol play/pause", "music", true),
            switchRow("Flashlight", "Saat senter menyala", "torch", true),
            switchRow("Charging", "Saat mengisi daya + persentase", "charge", true),
            switchRow("Hotspot", "Saat tethering aktif", "hotspot", true)))

        c.addView(card("Ukuran & penyesuaian",
            sliderRow("Lebar", "w", 320, 120, 400, "dp"),
            sliderRow("Tinggi konten", "h", 64, 32, 96, "dp"),
            sliderRow("Geser vertikal", "ay", 0, -40, 80, "dp"),
            sliderRow("Geser horizontal", "ax", 0, -60, 60, "dp")))

        setContentView(ScrollView(this).apply { addView(c); fitsSystemWindows = true })
    }

    override fun onResume() {
        super.onResume()
        refreshers.forEach { it() }
        p.edit().putLong("recheck", System.currentTimeMillis()).apply() // minta service memuat ulang sesi media
    }
}
