package com.dynamicisland.app

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.*
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.camera2.CameraManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.view.animation.PathInterpolator
import androidx.core.content.ContextCompat
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Host overlay. TYPE_ACCESSIBILITY_OVERLAY = digambar di ATAS status bar (menutupi pulau bawaan OEM)
 * dan service tetap hidup = mode standby. Window selalu pas dengan pill supaya sentuhan lain tidak terblokir.
 */
class IslandService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var wm: WindowManager
    private lateinit var p: SharedPreferences
    private lateinit var view: IslandView
    private val h = Handler(Looper.getMainLooper())
    private val lp = WindowManager.LayoutParams(1, 1, TYPE_ACCESSIBILITY_OVERLAY,
        FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL or FLAG_LAYOUT_NO_LIMITS or FLAG_LAYOUT_IN_SCREEN or FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT)

    private var attached = false
    private var userCollapsed = false
    private var last: String? = null
    private var lastKey = ""
    private var anim: ValueAnimator? = null
    private var cut: Rect? = null
    private var torch = false
    private var hotspot = false
    private var charging = false
    private var level = 0
    private var lastPlayingAt = 0L
    private var ctl: MediaController? = null
    private var msListener: MediaSessionManager.OnActiveSessionsChangedListener? = null

    // ---------- sumber data ----------
    private val mcb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            if (state?.state == PlaybackState.STATE_PAUSED) h.postDelayed({ render() }, PAUSE_GRACE + 300)
            render()
        }
        override fun onMetadataChanged(metadata: MediaMetadata?) = render()
        override fun onSessionDestroyed() { initMedia() }
    }
    private val batteryRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            render()
        }
    }
    private val hotspotRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { hotspot = i.getIntExtra("wifi_state", 11) == 13; render() }
    }
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) { torch = enabled; render() }
    }

    private fun initMedia() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MediaListener::class.java)
            if (msListener == null) {
                msListener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
                msm.addOnActiveSessionsChangedListener(msListener!!, cn)
            }
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) { msListener = null } // Notification Access belum diizinkan
    }

    private fun pick(list: List<MediaController>?) {
        ctl?.unregisterCallback(mcb)
        val l = list.orEmpty()
        ctl = l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        ctl?.registerCallback(mcb, h)
        render()
    }

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        p = getSharedPreferences("island", MODE_PRIVATE)
        view = IslandView(this).apply {
            onTap = { if (last != null) { userCollapsed = !userCollapsed; render() } }
            onAction = { toggleMusic() }
        }
        lp.gravity = Gravity.TOP or Gravity.START
        lp.layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30) LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            else LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        ContextCompat.registerReceiver(this, batteryRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_EXPORTED)
        ContextCompat.registerReceiver(this, hotspotRx, IntentFilter("android.net.wifi.WIFI_AP_STATE_CHANGED"), ContextCompat.RECEIVER_EXPORTED)
        getSystemService(CameraManager::class.java).registerTorchCallback(torchCb, h)
        initMedia()
        p.registerOnSharedPreferenceChangeListener(this)
        render()
    }

    /** Hanya pause/play dari kondisi yang jelas. Tidak pernah memulai musik dari kondisi stop/kosong. */
    private fun toggleMusic() {
        val c = ctl ?: return
        when (c.playbackState?.state) {
            PlaybackState.STATE_PLAYING -> c.transportControls.pause()
            PlaybackState.STATE_PAUSED -> c.transportControls.play()
            else -> {}
        }
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences, key: String?) {
        if (key == "recheck") initMedia()
        render()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        lastKey = ""; cut = null
        h.post { render() }
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        runCatching { p.unregisterOnSharedPreferenceChangeListener(this) }
        runCatching { unregisterReceiver(batteryRx); unregisterReceiver(hotspotRx) }
        runCatching { getSystemService(CameraManager::class.java).unregisterTorchCallback(torchCb) }
        runCatching { msListener?.let { getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(it) } }
        ctl?.unregisterCallback(mcb)
        detach()
        super.onDestroy()
    }

    // ---------- layar & geometri ----------
    private fun screenW(): Int = if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.width()
        else DisplayMetrics().also { @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(it) }.widthPixels

    private fun refreshCutout() {
        cut = if (Build.VERSION.SDK_INT >= 30)
            Cutout.top(wm.currentWindowMetrics.windowInsets) ?: (if (attached) Cutout.top(view.rootWindowInsets) else null)
        else if (attached) Cutout.top(view.rootWindowInsets) else cut
    }

    /** Hitung target geometri untuk state: idle (standby), compact (ikon saja), expanded. */
    private fun target(a: String?, expanded: Boolean): IslandView.Geo {
        val d = resources.displayMetrics.density
        val sw = screenW().toFloat()
        val cr = cut
        val auto = p.getBoolean("cutout", true) && cr != null
        val cx = (if (auto) cr!!.exactCenterX() else sw / 2f) + p.getInt("ax", 0) * d
        val top = (if (auto) max(0f, cr!!.top - 3 * d) else 8 * d) + p.getInt("ay", 0) * d
        val idleW = if (auto) cr!!.width() + 8 * d else 68 * d
        val idleH = if (auto) cr!!.height() + 6 * d else 30 * d
        val g = IslandView.Geo(t = top)
        when {
            a == null -> { g.w = idleW; g.h = idleH; g.icx = idleW / 2; g.icy = idleH / 2; g.ch = idleH }
            !expanded -> {
                // compact: ikon di samping kamera supaya tidak tertutup lubang
                if (auto) { g.w = idleW + 68 * d; g.h = idleH; g.icx = 17 * d } else { g.w = 68 * d; g.h = 30 * d; g.icx = 34 * d }
                g.icy = g.h / 2; g.ia = 1f; g.ch = g.h
            }
            else -> {
                g.w = min(p.getInt("w", 320) * d, sw - 24 * d)
                g.pad = if (auto) cr!!.bottom - top + 4 * d else 0f   // konten dibuka DI BAWAH kamera
                g.ch = p.getInt("h", 64) * d
                g.h = g.pad + g.ch; g.icx = 32 * d; g.icy = g.pad + g.ch / 2; g.ia = 1f; g.ca = 1f
            }
        }
        g.l = if (expanded && a != null) (cx - g.w / 2).coerceIn(12 * d, max(12 * d, sw - 12 * d - g.w)) else cx - g.w / 2
        return g
    }

    private fun mix(a: IslandView.Geo, b: IslandView.Geo, f: Float): IslandView.Geo {
        fun l(x: Float, y: Float) = x + (y - x) * f
        val ca = when {
            b.ca > a.ca -> ((f - 0.3f) / 0.7f).coerceIn(0f, 1f)   // konten muncul belakangan
            b.ca < a.ca -> (1f - f / 0.35f).coerceIn(0f, 1f)      // konten hilang duluan
            else -> a.ca
        }
        return IslandView.Geo(l(a.l, b.l), l(a.t, b.t), l(a.w, b.w), l(a.h, b.h), l(a.icx, b.icx), l(a.icy, b.icy),
            l(a.ia, b.ia), ca, l(a.pad, b.pad), l(a.ch, b.ch))
    }

    private fun applyWindow(l: Float, t: Float, r: Float, b: Float) {
        lp.x = floor(l).toInt(); lp.y = floor(t).toInt()
        lp.width = max(1, ceil(r).toInt() - lp.x); lp.height = max(1, ceil(b).toInt() - lp.y)
        if (attached) runCatching { wm.updateViewLayout(view, lp) }
    }

    private fun go(a: String?, expanded: Boolean) {
        val to = target(a, expanded)
        val key = "$a|$expanded"
        if (lastKey.isEmpty() || key == lastKey) {
            if (anim?.isRunning == true || view.g == to) return
            lastKey = key; view.g = to
            applyWindow(to.l, to.t, to.l + to.w, to.t + to.h); view.invalidate(); return
        }
        val from = view.g.copy()
        anim?.cancel(); lastKey = key
        // window = gabungan posisi awal & akhir, diubah SEKALI; animasi hanya menggambar ulang (tanpa relayout)
        applyWindow(min(from.l, to.l), min(from.t, to.t), max(from.l + from.w, to.l + to.w), max(from.t + from.h, to.t + to.h))
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (expanded) 520 else 380; startDelay = 16
            interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)   // emphasized decelerate (stock Material 3)
            addUpdateListener { view.g = mix(from, to, it.animatedFraction); view.invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                var cancelled = false
                override fun onAnimationCancel(an: Animator) { cancelled = true }
                override fun onAnimationEnd(an: Animator) {
                    if (cancelled) return
                    view.g = to; applyWindow(to.l, to.t, to.l + to.w, to.t + to.h); view.invalidate()
                }
            })
            start()
        }
    }

    // ---------- state ----------
    private fun activeState(): String? {
        val s = ctl?.playbackState?.state
        val now = System.currentTimeMillis()
        if (s == PlaybackState.STATE_PLAYING) lastPlayingAt = now
        val music = s == PlaybackState.STATE_PLAYING || (s == PlaybackState.STATE_PAUSED && now - lastPlayingAt < PAUSE_GRACE)
        return when {
            p.getBoolean("music", true) && music -> "music"
            p.getBoolean("torch", true) && torch -> "torch"
            p.getBoolean("hotspot", true) && hotspot -> "hotspot"
            p.getBoolean("charge", true) && charging -> "charge"
            else -> null
        }
    }

    private fun detach() {
        anim?.cancel(); lastKey = ""
        if (attached) { runCatching { wm.removeView(view) }; attached = false }
    }

    private fun render() {
        if (!::p.isInitialized) return
        refreshCutout()
        val a = activeState()
        if (a != last) { userCollapsed = false; last = a }
        // Mode standby: pill tetap tampil walau tidak ada fitur aktif
        if (!p.getBoolean("enabled", false) || (a == null && !p.getBoolean("standby", true))) { detach(); return }
        if (!attached) {
            view.alpha = 0f
            attached = runCatching { wm.addView(view, lp); true }.getOrDefault(false)
            view.animate().alpha(1f).setDuration(220).start()
            view.post { if (Build.VERSION.SDK_INT < 30) render() } // API < 30: insets baru tersedia setelah attach
        }
        when (a) {
            "music" -> {
                val m = ctl?.metadata
                val playing = ctl?.playbackState?.state == PlaybackState.STATE_PLAYING
                view.iconRes = R.drawable.ic_music
                view.title = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Now Playing"
                view.sub = (if (playing) "Playing" else "Paused") +
                    (m?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.let { " · $it" } ?: "")
                view.playing = playing
            }
            "torch" -> { view.iconRes = R.drawable.ic_torch; view.title = "Flashlight"; view.sub = "Senter menyala" }
            "hotspot" -> { view.iconRes = R.drawable.ic_hotspot; view.title = "Hotspot"; view.sub = "Tethering aktif" }
            "charge" -> { view.iconRes = R.drawable.ic_battery; view.title = "Charging"; view.sub = "$level%" }
            else -> view.iconRes = 0
        }
        view.showAction = a == "music"
        go(a, a != null && !userCollapsed)
    }

    companion object { private const val PAUSE_GRACE = 10_000L }
}
