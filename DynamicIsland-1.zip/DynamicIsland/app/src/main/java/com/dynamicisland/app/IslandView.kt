package com.dynamicisland.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.hypot
import kotlin.math.min

/**
 * Seluruh pulau digambar langsung di canvas (tanpa relayout per frame) sehingga animasi mulus.
 * Koordinat Geo = koordinat layar; posisi window dibaca via getLocationOnScreen saat menggambar.
 */
class IslandView(ctx: Context) : View(ctx) {
    data class Geo(
        var l: Float = 0f, var t: Float = 0f, var w: Float = 0f, var h: Float = 0f,
        var icx: Float = 0f, var icy: Float = 0f,   // pusat ikon relatif ke pill
        var ia: Float = 0f, var ca: Float = 0f,     // alpha ikon, alpha konten
        var pad: Float = 0f, var ch: Float = 0f     // area konten: offset atas & tinggi (di bawah kamera)
    )

    var g = Geo()
    var iconRes = 0
    var title = ""
    var sub = ""
    var showAction = false
    var playing = false
    var onTap: (() -> Unit)? = null
    var onAction: (() -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val act = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 13 * d; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val sp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 11 * d }
    private val loc = IntArray(2)
    private val icons = HashMap<Int, Drawable>()
    private var down = false

    private fun dr(res: Int) = icons.getOrPut(res) { ContextCompat.getDrawable(context, res)!!.mutate() }

    override fun onDraw(c: Canvas) {
        getLocationOnScreen(loc)
        val ox = g.l - loc[0]; val oy = g.t - loc[1]
        val r = min(g.h / 2f, 36 * d)
        c.drawRoundRect(ox, oy, ox + g.w, oy + g.h, r, r, bg)

        if (iconRes != 0 && g.ia > 0.01f) {
            val s = (18 + 2 * g.ca) * d
            val cx = ox + g.icx; val cy = oy + g.icy
            dr(iconRes).apply {
                setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
                alpha = (g.ia * 255).toInt(); draw(c)
            }
        }
        if (g.ca > 0.01f) {
            val cy = oy + g.pad + g.ch / 2f
            val left = ox + 52 * d
            val right = ox + g.w - (if (showAction) 58 else 22) * d
            val avail = (right - left).coerceAtLeast(1f)
            tp.alpha = (g.ca * 255).toInt(); sp.alpha = (g.ca * 140).toInt()
            val th = tp.descent() - tp.ascent(); val sh = sp.descent() - sp.ascent()
            val top = cy - (th + sh + d) / 2f
            c.save(); c.clipRect(ox, oy, ox + g.w, oy + g.h)
            c.drawText(TextUtils.ellipsize(title, tp, avail, TextUtils.TruncateAt.END).toString(), left, top - tp.ascent(), tp)
            c.drawText(TextUtils.ellipsize(sub, sp, avail, TextUtils.TruncateAt.END).toString(), left, top + th + d - sp.ascent(), sp)
            c.restore()
            if (showAction) {
                val ax = ox + g.w - 28 * d
                act.alpha = (g.ca * 0x1F).toInt()
                c.drawCircle(ax, cy, 18 * d, act)
                val s = 15 * d
                dr(if (playing) R.drawable.ic_pause else R.drawable.ic_play).apply {
                    setBounds((ax - s / 2).toInt(), (cy - s / 2).toInt(), (ax + s / 2).toInt(), (cy + s / 2).toInt())
                    alpha = (g.ca * 255).toInt(); draw(c)
                }
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        getLocationOnScreen(loc)
        val ox = g.l - loc[0]; val oy = g.t - loc[1]
        val inside = e.x in ox..(ox + g.w) && e.y in oy..(oy + g.h)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = inside; return inside }
            MotionEvent.ACTION_UP -> if (down && inside) {
                val ax = ox + g.w - 28 * d; val ay = oy + g.pad + g.ch / 2f
                // Tombol hanya aktif saat pulau SUDAH terbuka penuh (mencegah tap tak sengaja = musik main sendiri)
                if (showAction && g.ca > 0.95f && hypot(e.x - ax, e.y - ay) < 24 * d) onAction?.invoke()
                else onTap?.invoke()
                down = false
            }
            MotionEvent.ACTION_CANCEL -> down = false
        }
        return down
    }
}
