package com.dynamicisland.app

import android.service.notification.NotificationListenerService

/** Dibutuhkan agar app boleh membaca sesi media aktif (judul, artis, play/pause). */
class MediaListener : NotificationListenerService()
