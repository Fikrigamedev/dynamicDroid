package com.dynamicisland.app

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.view.animation.PathInterpolator
import android.widget.*
import androidx.core.content.ContextCompat

/**
 * Host overlay Dynamic Island. Memakai TYPE_ACCESSIBILITY_OVERLAY sehingga digambar DI ATAS status bar
 * (menutupi indikator/pulau bawaan OEM) dan service ini hidup terus = mode standby.
 */
class IslandService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var wm: WindowManager
    private lateinit var p: SharedPreferences
    private lateinit var root: FrameLayout
    private lateinit var pill: FrameLayout
    private lateinit var bg: GradientDrawable
    private lateinit var icon: ImageView
    private lateinit var texts: LinearLayout
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var action: ImageButton
    private val h = Handler(Looper.getMainLooper())
    private val lp = WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, TYPE_ACCESSIBILITY_OVERLAY,
        FLAG_NOT_FOCUSABLE or FLAG_NOT_TOUCH_MODAL or FLAG_LAYOUT_NO_LIMITS or FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT)

    private var attached = false
    private var userCollapsed = false
    private var last: String? = null
    private var curW = 0
    private var curH = 0
    private var anim: ValueAnimator? = null
    private var torch = false
    private var hotspot = false
    private var charging = false
    private var level = 0
    private var ctl: MediaController? = null
    private var msListener: MediaSessionManager.OnActiveSessionsChangedListener? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- sumber data ----------
    private val mcb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = render()
        override fun onMetadataChanged(metadata: MediaMetadata?) = render()
        override fun onSessionDestroyed() { initMedia() }
    }
    private val batteryRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            charging = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
            level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            render()
        }
    }
    private val hotspotRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            hotspot = i.getIntExtra("wifi_state", 11) == 13 // WIFI_AP_STATE_ENABLED
            render()
        }
    }
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) { torch = enabled; render() }
    }

    private fun initMedia() {
        try {
            val msm = getSystemService(MediaSessionManager::class.java)
            val cn = ComponentName(this, MediaListener::class.java)
            if (msListener == null) {
                msListener = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }
                msm.addOnActiveSessionsChangedListener(msListener!!, cn)
            }
            pick(msm.getActiveSessions(cn))
        } catch (e: SecurityException) { msListener = null } // izin Notification Access belum diberikan
    }

    private fun pick(list: List<MediaController>?) {
        ctl?.unregisterCallback(mcb)
        val l = list.orEmpty()
        ctl = l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PAUSED }
        ctl?.registerCallback(mcb, h)
        render()
    }

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        p = getSharedPreferences("island", MODE_PRIVATE)
        buildView()
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        ContextCompat.registerReceiver(this, batteryRx, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_EXPORTED)
        ContextCompat.registerReceiver(this, hotspotRx, IntentFilter("android.net.wifi.WIFI_AP_STATE_CHANGED"), ContextCompat.RECEIVER_EXPORTED)
        getSystemService(CameraManager::class.java).registerTorchCallback(torchCb, h)
        initMedia()
        p.registerOnSharedPreferenceChangeListener(this)
        render()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences, key: String?) {
        if (key == "recheck") initMedia()
        render()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        runCatching { p.unregisterOnSharedPreferenceChangeListener(this) }
        runCatching { unregisterReceiver(batteryRx); unregisterReceiver(hotspotRx) }
        runCatching { getSystemService(CameraManager::class.java).unregisterTorchCallback(torchCb) }
        runCatching { msListener?.let { getSystemService(MediaSessionManager::class.java).removeOnActiveSessionsChangedListener(it) } }
        ctl?.unregisterCallback(mcb)
        detach()
        super.onDestroy()
    }

    // ---------- UI overlay ----------
    private fun buildView() {
        bg = GradientDrawable().apply { setColor(Color.BLACK) }
        icon = ImageView(this).apply { setColorFilter(Color.WHITE) }
        title = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 13f; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
        }
        sub = TextView(this).apply {
            setTextColor(0x8CFFFFFF.toInt()); textSize = 11f; setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END
        }
        texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; alpha = 0f
            addView(title); addView(sub)
        }
        action = ImageButton(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x1FFFFFFF) }
            setColorFilter(Color.WHITE); setPadding(dp(10), dp(10), dp(10), dp(10)); visibility = View.GONE
            setOnClickListener {
                ctl?.let { c ->
                    if (c.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
                    else c.transportControls.play()
                }
            }
        }
        pill = FrameLayout(this).apply {
            background = bg; clipChildren = true; elevation = dp(6).toFloat()
            addView(icon, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER_VERTICAL or Gravity.START).apply { marginStart = dp(24) })
            addView(texts, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_VERTICAL).apply { marginStart = dp(52); marginEnd = dp(54) })
            addView(action, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.CENTER_VERTICAL or Gravity.END).apply { marginEnd = dp(10) })
            setOnClickListener { if (last != null) { userCollapsed = !userCollapsed; render() } }
        }
        root = FrameLayout(this).apply { addView(pill, FrameLayout.LayoutParams(dp(68), dp(30))) }
    }

    private fun attach() {
        lp.x = dp(p.getInt("x", 0)); lp.y = dp(p.getInt("top", 8))
        if (!attached) {
            curW = dp(68); curH = dp(30); applySize()
            runCatching { wm.addView(root, lp); attached = true }
        } else runCatching { wm.updateViewLayout(root, lp) }
    }

    private fun detach() {
        anim?.cancel()
        if (attached) { runCatching { wm.removeView(root) }; attached = false }
    }

    private fun applySize() {
        pill.layoutParams = FrameLayout.LayoutParams(curW, curH)
        bg.cornerRadius = curH / 2f
    }

    private fun morph(w: Int, hh: Int, expanded: Boolean) {
        if (w == curW && hh == curH) return
        anim?.cancel()
        val w0 = curW; val h0 = curH
        texts.animate().alpha(if (expanded) 1f else 0f).setDuration(if (expanded) 250 else 100).setStartDelay(if (expanded) 150 else 0).start()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450; interpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
            addUpdateListener {
                val f = it.animatedFraction
                curW = (w0 + (w - w0) * f).toInt(); curH = (h0 + (hh - h0) * f).toInt(); applySize()
            }
            start()
        }
    }

    private fun activeState(): String? {
        val s = ctl?.playbackState?.state
        return when {
            p.getBoolean("music", true) && (s == PlaybackState.STATE_PLAYING || s == PlaybackState.STATE_PAUSED) -> "music"
            p.getBoolean("torch", true) && torch -> "torch"
            p.getBoolean("hotspot", true) && hotspot -> "hotspot"
            p.getBoolean("charge", true) && charging -> "charge"
            else -> null
        }
    }

    private fun render() {
        if (!::p.isInitialized) return
        val a = activeState()
        if (a != last) { userCollapsed = false; last = a }
        // Mode standby: pill kecil tetap tampil walau tidak ada fitur aktif
        if (!p.getBoolean("enabled", false) || (a == null && !p.getBoolean("standby", true))) { detach(); return }
        attach()

        when (a) {
            "music" -> {
                val m = ctl?.metadata
                val playing = ctl?.playbackState?.state == PlaybackState.STATE_PLAYING
                icon.setImageResource(R.drawable.ic_music)
                title.text = m?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Now Playing"
                sub.text = (if (playing) "Playing" else "Paused") +
                    (m?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.let { " · $it" } ?: "")
                action.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
            }
            "torch" -> { icon.setImageResource(R.drawable.ic_torch); title.text = "Flashlight"; sub.text = "Senter menyala" }
            "hotspot" -> { icon.setImageResource(R.drawable.ic_hotspot); title.text = "Hotspot"; sub.text = "Tethering aktif" }
            "charge" -> { icon.setImageResource(R.drawable.ic_battery); title.text = "Charging"; sub.text = "$level%" }
            else -> icon.setImageDrawable(null)
        }
        val expanded = a != null && !userCollapsed
        action.visibility = if (expanded && a == "music") View.VISIBLE else View.GONE
        val maxW = resources.displayMetrics.widthPixels - dp(32)
        morph(if (expanded) minOf(dp(p.getInt("w", 320)), maxW) else dp(68),
            if (expanded) dp(p.getInt("h", 64)) else dp(30), expanded)
    }
}
