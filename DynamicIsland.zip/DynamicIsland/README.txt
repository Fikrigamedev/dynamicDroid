Dynamic Island (Android, Kotlin, Material 3)
1. Buka folder ini di Android Studio (Koala atau lebih baru), tunggu Gradle sync.
2. Build > Build APK(s)  (atau Run di HP).
3. Install, buka app, aktifkan toggle, lalu beri izin: Aksesibilitas + Akses notifikasi (+ abaikan optimasi baterai).
